import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealVector;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.custom.CustomAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.Terms;
import org.apache.lucene.index.TermsEnum;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.search.similarities.BM25Similarity;
import org.apache.lucene.store.Directory;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.BytesRef;

public class FourthTask {
	//a)
	static int docnum=0;
	static FieldType ft=new FieldType();
	private static Set<String> terms = new HashSet<>();
    private static RealVector v1=null;
    private static RealVector v2=null;
    private static RealVector v3=null;
    private static RealVector v4=null;
    private static RealVector v5=null;
    private static RealVector v6=null;	 
	
	
	    
    
	// //adding docements to the directory (index) using IndexWriter
	private static void addDoc(IndexWriter w, String Main) throws IOException {
		Document doc = new Document();
		
		ft.setIndexOptions(IndexOptions.DOCS_AND_FREQS_AND_POSITIONS_AND_OFFSETS); //enable storing the reuired statistics
		ft.setStored(true);
		ft.setStoreTermVectors(true);
		ft.setStoreTermVectorPositions(true);
		ft.setStoreTermVectorPayloads(true);
		ft.setStoreTermVectorOffsets(true);
		doc.add(new Field("Main", Main, ft));
		w.addDocument(doc);
		docnum++;
		}
	
	
	public static void main(String[] args) throws IOException, ParseException {
		//analyzer only for lowercase and none letters characters
		Analyzer analyzer = CustomAnalyzer.builder()
				   .withTokenizer("standard")
				   .addTokenFilter("lowercase")
				   .build();
		
		Directory index = new RAMDirectory(); //makes a new directory in the ram for storing the index
		IndexWriterConfig config = new IndexWriterConfig(analyzer);
		IndexWriter writer = new IndexWriter(index, config); // making IndexWriter to add document to the index
		
		//adding docements to the directory (index) using IndexWriter by calling the method addDoc()
		String d1="Today is sunny.";
		String d2=" She is a sunny girl.";
		String d3="To be or not to be.";
		String d4="She is in Berlin today.";
		String d5="Sunny Berlin sunny!";
		String d6="Berlin is always exciting!";
		addDoc(writer, d1);
		addDoc(writer, d2);
		addDoc(writer, d3);
		addDoc(writer, d4);
		addDoc(writer, d5);
		addDoc(writer, d6);
		writer.close();
		
		
		
		
		IndexReader reader = DirectoryReader.open(index);	//reader to read the index
		
		
		addTerms(reader, 0);
        addTerms(reader, 1);
        addTerms(reader, 2);
        addTerms(reader, 3);
        addTerms(reader, 4);
        addTerms(reader, 5);
        
		
		
        v1 = getTermFrequencies(reader, 0);
        v2 = getTermFrequencies(reader, 1);
        v3 = getTermFrequencies(reader, 2);
        v4 = getTermFrequencies(reader, 3);
        v5 = getTermFrequencies(reader, 4);
        v6 = getTermFrequencies(reader, 5);
       
        //a) 1)
        double euk = getEukSimilarity(v1,v2);
        double dot = getDotSimilarity(v1,v2);
        double cos = getCosineSimilarity(v1,v2);
        
        System.out.println("a) \n1)");
        
        System.out.println("euclidean distance similarity between doc1 and doc2 = "+euk);
        System.out.println("Dot product similarity between doc1 and doc2 = "+dot);
        System.out.println("cosine similarity between doc1 and doc2 = "+cos);
        
        System.out.println("--------------------------------------------------------------------------");
		
        RealVector v7 = new ArrayRealVector(terms.size());
        //a) 2)

        System.out.println("\n2)\nquery: to sunny girl. \nsimilarity score: ");
        int i=0;
        String q[] = {"to", "sunny", "girl"};
     	for(String term:terms) {
     		int w=0;
     		for(int j=0;j<q.length;j++) {
     			if(term.equals(q[j])) {
     				w=1;
     			}
     		}
     		v7.setEntry(i++, w);
     	}
     	
        double cos1 = getCosineSimilarity(v7,v1);
        double cos2 = getCosineSimilarity(v7,v2);
        double cos3 = getCosineSimilarity(v7,v3);
        double cos4 = getCosineSimilarity(v7,v4);
        double cos5 = getCosineSimilarity(v7,v5);
        double cos6 = getCosineSimilarity(v7,v6);
        System.out.println("doc 1 = "+cos1);
        System.out.println("doc 2 = "+cos2);
        System.out.println("doc 3 = "+cos3);
        System.out.println("doc 4 = "+cos4);
        System.out.println("doc 5 = "+cos5);
        System.out.println("doc 6 = "+cos6);
        
        String rank1[]= {d1,d2,d3,d4,d5,d6};
        double rank[]= {cos1,cos2,cos3,cos4,cos5,cos6};
        double rank2[]={cos1,cos2,cos3,cos4,cos5,cos6}; 
        Arrays.sort(rank2);
        

        System.out.println("ranking: ");
        for(int j = rank.length-1,k=1;j>=0;j--) {
        	boolean bool=false;
        	for(int n=0;bool==false;n++){
        		if(rank[n]==rank2[j]) {
        			System.out.println("Rank "+k+" = "+rank1[n]);	
        			rank[n]=Integer.MAX_VALUE;
        			if(j>0) {
        				if(rank2[j]!=rank2[j-1]) {
        					k++;
        				}
        			}
        			bool=true;
        		}
        	}
        }
        System.out.println("--------------------------------------------------------------------------");
		
        
        //b) vsm
        System.out.println("b) \n find relevant documents while querying the following document (She is a sunny girl.) using the vector space model: ");
        
        
        RealVector v8 = new ArrayRealVector(terms.size());
        int l=0;
        String q2[] = {"she","is","a", "sunny", "girl"};
     	for(String term:terms) {
     		int w=0;
     		for(int j=0;j<q2.length;j++) {
     			if(term.equals(q2[j])) {
     				w=1;
     			}
     		}
     		v8.setEntry(l++, w);
     	}
     	
        double cosi1 = getCosineSimilarity(v8,v1);
        double cosi2 = getCosineSimilarity(v8,v2);
        double cosi3 = getCosineSimilarity(v8,v3);
        double cosi4 = getCosineSimilarity(v8,v4);
        double cosi5 = getCosineSimilarity(v8,v5);
        double cosi6 = getCosineSimilarity(v8,v6);
        
        String ranki1[]= {d1,d2,d3,d4,d5,d6};
        double ranki[]= {cosi1,cosi2,cosi3,cosi4,cosi5,cosi6};
        double ranki2[]={cosi1,cosi2,cosi3,cosi4,cosi5,cosi6}; 
        Arrays.sort(ranki2);
        
        System.out.println("ranking: ");
        
        for(int j = ranki.length-1;j>=0;j--) {
        	if(ranki2[j]==0.0) {
        		break;
        	}
        	boolean bool=false;
        	for(int n=0;bool==false;n++){
        		if(ranki[n]==ranki2[j]) {
        			System.out.println("<"+ranki2[j]+">"+" : "+"<"+ranki1[n]+">");	
        			ranki[n]=Integer.MAX_VALUE;
        			bool=true;
        		}
        	}
        }
        
        System.out.println("--------------------------------------------------------------------------");
		
        
        //b) BM25
        System.out.println(" \nfind relevant documents while querying the following document (She is a sunny girl.) using the BM25 model: ");
        
        IndexSearcher searcher = new IndexSearcher(reader);
        searcher.setSimilarity(new BM25Similarity());
        String queryString = "She is a sunny girl";
        QueryParser parser = new QueryParser("Main", analyzer);
        Query query = parser.parse(queryString);
        
        TopScoreDocCollector docCollcetor = TopScoreDocCollector.create(10);
        searcher.search(query, docCollcetor);
        System.out.println("ranking: ");
        
        ScoreDoc[] docs = docCollcetor.topDocs().scoreDocs;
        for (int j = 0; j < docs.length && j < 10; j++) {
            Document doc = searcher.doc(docs[j].doc);
            System.out.println("<"+ docs[j].score+ ">"+" : "+ "<"+ doc.get("Main")+">");
        }
        reader.close();
        
        	}

    public static double getCosineSimilarity(RealVector s1, RealVector s2)
            throws IOException {
        return (s1.dotProduct(s2)) / (s1.getNorm() * s2.getNorm());
    }
    
    public static double getDotSimilarity(RealVector s1, RealVector s2)
            throws IOException {
    	return s1.dotProduct(s2);
    }
    
    public static double getEukSimilarity(RealVector s1, RealVector s2)
            throws IOException {
        return s1.getDistance(s2);
    }

    static RealVector getTermFrequencies(IndexReader reader, int docId)
            throws IOException {
        Terms vector = reader.getTermVector(docId, "Main");
        double n=reader.getDocCount("Main");
        TermsEnum termsEnum = null;
        termsEnum = vector.iterator();
        Map<String, Integer> frequencies = new HashMap<>();
        RealVector rvector = new ArrayRealVector(terms.size());
        BytesRef text = null;
        ArrayList<Term> v=new ArrayList<Term>();
        ArrayList<Long> g=new ArrayList<Long>();
        while ((text = termsEnum.next()) != null) {
        	String term = text.utf8ToString();
        	int freq = (int) termsEnum.totalTermFreq();
        	Term termInstance = new Term("Main", term);
        	frequencies.put(term, freq);
            v.add(termInstance);
            g.add(termsEnum.totalTermFreq());
        }
        int i = 0;
        //int j=0;
        double idf=0.0;
        double tf=0.0;
        double tfidf=0.0;
        for (String term1 : terms) {
            if(frequencies.containsKey(term1)) {
            	Term termm = new Term("Main", term1);
            	int index=v.indexOf(termm);
            	Term termInstance=v.get(index);
            	tf=g.get(index);
    			double docCount = reader.docFreq(termInstance);
    			double z=n/docCount;
            	idf=Math.log10(z);
            	tfidf=tf*idf;
    	    	} else {
            		tfidf=0.0;
                	}
            rvector.setEntry(i++, tfidf);
        }
        return rvector;
    }

    
    static void addTerms(IndexReader reader, int docId) throws IOException {
    	Terms vector = reader.getTermVector(docId, "Main");
        TermsEnum termsEnum = null;
        termsEnum = vector.iterator();
        BytesRef text = null;
        while ((text = termsEnum.next()) != null) {
            String term = text.utf8ToString();
            terms.add(term);
        }
    }
    
}